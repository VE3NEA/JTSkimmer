To install JT Skimmer:
 1. run JTSkimmerSetup.exe and follow the instructions.
 2. replace jt9.exe in the WSJT-X installation with the attached one.